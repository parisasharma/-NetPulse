"""
routers/alerts.py
─────────────────
GET  /alerts              → list all alerts (filter by resolved status)
GET  /alerts/{id}         → single alert
PUT  /alerts/{id}/resolve → manually resolve an alert
DELETE /alerts/{id}       → delete an alert
"""

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import desc
from typing import List
from datetime import datetime

from app.database import get_db
from app import models, schemas

router = APIRouter(tags=["Alerts"])


@router.get("/alerts", response_model=List[schemas.AlertResponse])
def list_alerts(
    resolved: bool = Query(False, description="Include resolved alerts"),
    limit: int = Query(50, ge=1, le=500),
    db: Session = Depends(get_db),
):
    query = db.query(models.Alert)
    if not resolved:
        query = query.filter(models.Alert.is_resolved == False)
    return query.order_by(desc(models.Alert.created_at)).limit(limit).all()


@router.get("/alerts/{alert_id}", response_model=schemas.AlertResponse)
def get_alert(alert_id: int, db: Session = Depends(get_db)):
    alert = db.query(models.Alert).filter(models.Alert.id == alert_id).first()
    if not alert:
        raise HTTPException(status_code=404, detail="Alert not found.")
    return alert


@router.put("/alerts/{alert_id}/resolve", response_model=schemas.AlertResponse)
def resolve_alert(alert_id: int, db: Session = Depends(get_db)):
    alert = db.query(models.Alert).filter(models.Alert.id == alert_id).first()
    if not alert:
        raise HTTPException(status_code=404, detail="Alert not found.")
    alert.is_resolved = True
    alert.resolved_at = datetime.utcnow()
    db.commit()
    db.refresh(alert)
    return alert


@router.delete("/alerts/{alert_id}", status_code=204)
def delete_alert(alert_id: int, db: Session = Depends(get_db)):
    alert = db.query(models.Alert).filter(models.Alert.id == alert_id).first()
    if not alert:
        raise HTTPException(status_code=404, detail="Alert not found.")
    db.delete(alert)
    db.commit()
